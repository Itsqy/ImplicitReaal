package com.syatria.implicitintentreal

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_phone.*
import kotlinx.android.synthetic.main.activity_sms.*

class SmsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        btn_pilih_kontak_sms.setOnClickListener {
            val i = Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI)
            i.data = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            startActivityForResult(i, 99)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {


        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 99) {
            if (resultCode == Activity.RESULT_OK) {
                val uri = data?.data
                val cursor = contentResolver.query(
                    uri!!,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                    ), null, null, null
                )

                if (cursor != null && cursor.moveToNext()) {
                    val noTel = cursor.getString(0)
                    edt_no_telp.setText(noTel)
                }
            }
        } else if (resultCode == Activity.RESULT_CANCELED) {

            edt_no_telp.setText("")
            Toast.makeText(this, "Cancel Ambil KONTAK", Toast.LENGTH_SHORT).show()
        }
    }
}